#!/bin/zsh
set -e

MODEL="${1:-llama3.2}"
OLLAMA_APP="/Applications/Ollama.app"
LOCAL_OLLAMA_APP="$HOME/Applications/Ollama.app"

echo "Student Command free AI setup"
echo "Model: $MODEL"
echo ""

if [ -d "$OLLAMA_APP" ]; then
  open -ga "Ollama" || open "$OLLAMA_APP"
elif [ -d "$LOCAL_OLLAMA_APP" ]; then
  open "$LOCAL_OLLAMA_APP"
else
  echo "Ollama is not installed yet."
  echo "Opening the Ollama download page..."
  open "https://ollama.com/download"
  echo ""
  echo "Install Ollama, then run this file again."
  read "?Press Return to close."
  exit 1
fi

sleep 3

if command -v ollama >/dev/null 2>&1; then
  OLLAMA_BIN="$(command -v ollama)"
elif [ -x "$OLLAMA_APP/Contents/Resources/ollama" ]; then
  OLLAMA_BIN="$OLLAMA_APP/Contents/Resources/ollama"
elif [ -x "$LOCAL_OLLAMA_APP/Contents/Resources/ollama" ]; then
  OLLAMA_BIN="$LOCAL_OLLAMA_APP/Contents/Resources/ollama"
else
  echo "Ollama opened, but the command line tool was not found."
  echo "Open Terminal later and run: ollama pull $MODEL"
  read "?Press Return to close."
  exit 1
fi

echo "Downloading/checking model. This can take a while the first time."
"$OLLAMA_BIN" pull "$MODEL"

echo ""
echo "Free local AI is ready for Student Command."
read "?Press Return to close."
